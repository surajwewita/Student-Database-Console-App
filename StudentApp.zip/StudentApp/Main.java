import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final StudentDAO dao = new StudentDAO();

    public static void main(String[] args) {
        while (true) {
            printMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1": addStudent(); break;
                case "2": updateStudent(); break;
                case "3": deleteStudent(); break;
                case "4": viewStudentById(); break;
                case "5": listAll(); break;
                case "0": System.out.println("Goodbye!"); System.exit(0);
                default: System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n=== Student Manager ===");
        System.out.println("1) Add student");
        System.out.println("2) Update student");
        System.out.println("3) Delete student");
        System.out.println("4) View student by id");
        System.out.println("5) List all students");
        System.out.println("0) Exit");
        System.out.print("Choose: ");
    }

    private static void addStudent() {
        System.out.print("Name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Email: ");
        String email = scanner.nextLine().trim();

        System.out.print("DOB (YYYY-MM-DD) or leave blank: ");
        String dobStr = scanner.nextLine().trim();
        Date dob = null;
        if (!dobStr.isEmpty()) {
            try { dob = Date.valueOf(dobStr); }
            catch (IllegalArgumentException e) {
                System.out.println("Invalid date format. Use YYYY-MM-DD.");
                return;
            }
        }

        System.out.print("Course: ");
        String course = scanner.nextLine().trim();

        Student s = new Student(name, email, dob, course);
        if (dao.addStudent(s)) {
            System.out.println("Added! New ID: " + s.getId());
        } else {
            System.out.println("Failed to add student.");
        }
    }

    private static void updateStudent() {
        System.out.print("Enter student ID to update: ");
        int id = Integer.parseInt(scanner.nextLine().trim());
        Student existing = dao.getStudentById(id);
        if (existing == null) {
            System.out.println("Student not found.");
            return;
        }
        System.out.println("Leave blank to keep current value.");

        System.out.print("Name (" + existing.getName() + "): ");
        String name = scanner.nextLine().trim();
        if (!name.isEmpty()) existing.setName(name);

        System.out.print("Email (" + existing.getEmail() + "): ");
        String email = scanner.nextLine().trim();
        if (!email.isEmpty()) existing.setEmail(email);

        System.out.print("DOB (" + (existing.getDob() != null ? existing.getDob() : "N/A") + ") YYYY-MM-DD: ");
        String dobStr = scanner.nextLine().trim();
        if (!dobStr.isEmpty()) {
            try { existing.setDob(Date.valueOf(dobStr)); }
            catch (IllegalArgumentException e) { System.out.println("Invalid date format."); return; }
        }

        System.out.print("Course (" + existing.getCourse() + "): ");
        String course = scanner.nextLine().trim();
        if (!course.isEmpty()) existing.setCourse(course);

        if (dao.updateStudent(existing)) System.out.println("Updated.");
        else System.out.println("Update failed.");
    }

    private static void deleteStudent() {
        System.out.print("Enter student ID to delete: ");
        int id = Integer.parseInt(scanner.nextLine().trim());
        System.out.print("Are you sure? (y/N): ");
        String ok = scanner.nextLine().trim().toLowerCase();
        if (ok.equals("y")) {
            if (dao.deleteStudent(id)) System.out.println("Deleted.");
            else System.out.println("Delete failed or ID not found.");
        } else {
            System.out.println("Cancelled.");
        }
    }

    private static void viewStudentById() {
        System.out.print("Enter ID: ");
        int id = Integer.parseInt(scanner.nextLine().trim());
        Student s = dao.getStudentById(id);
        if (s == null) System.out.println("Not found.");
        else System.out.println(s);
    }

    private static void listAll() {
        List<Student> students = dao.getAllStudents();
        if (students.isEmpty()) System.out.println("No students.");
        else students.forEach(System.out::println);
    }
}
